Project Scope
A notebook application to create, edit, and delete notes

first release 11.01.2024
- reads previously saved notes from the TXT file
- 4 actions possible; add a new note, edit an existing note, delete an existing note, exit the program
- saves notes to a TXT file

update 14.01.2024
- a new feature added: marking notes as done
- some code improvements are done to the block of writing to a file.
- some comments are added

release v2.0 19.01.2024
- A user interface is added
- push button functions are implemented
- list widget is implemented
- text browser is implemented
- action messages and welcome message are now displays on the text browser

Cihan Şenyüz
